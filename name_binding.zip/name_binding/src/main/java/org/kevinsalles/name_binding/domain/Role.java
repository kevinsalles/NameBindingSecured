package org.kevinsalles.name_binding.domain;

public enum Role {
	ADMIN,
	CLIENT,
	AGENT;
}
