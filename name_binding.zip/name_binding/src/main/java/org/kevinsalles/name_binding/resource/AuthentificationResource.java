package org.kevinsalles.name_binding.resource;

import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.Response.Status;

import org.kevinsalles.name_binding.domain.User;
import org.kevinsalles.name_binding.filter.Secured;
import org.kevinsalles.name_binding.infrastructure.UserRepo;
import org.kevinsalles.name_binding.infrastructure.UserRepoSingleton;

@Path("/")
public class AuthentificationResource {
	
	
	@GET
	@Path("login/{username}/{password}")
	public Response login(@PathParam("username") String username,
			@PathParam("password") String password){
		
		Response response;
		UserRepo repo = UserRepoSingleton.getInstance();
		
		User user = repo.findByUsername(username);
		if(user != null){
			if(user.username.equals(username) && user.password.equals(password)){
				user.isAuthenficate = true;
				repo.addUser(user);
				response = Response.status(Status.OK).build();
			}
			else{
				response = Response.status(Status.UNAUTHORIZED).build();
			}
		}
		else{
			response = Response.status(Status.UNAUTHORIZED).build();
		}
		return response;
	}
	
	@GET
	@Secured
	@Path("logout")
	public Response logout(@HeaderParam("username") String username){
		
		Response response;
		UserRepo repo = UserRepoSingleton.getInstance();
		
		User user = repo.findByUsername(username);
		if(user != null){
				user.isAuthenficate = false;
				repo.addUser(user);
				response = Response.status(Status.OK).build();
		}
		else{
			response = Response.status(Status.NOT_FOUND).build();
		}
		return response;
	}
}
