package org.kevinsalles.name_binding.infrastructure;

import java.util.HashMap;
import java.util.Map;

import org.kevinsalles.name_binding.domain.User;

public class UserRepo {
	private Map<String,User> users = new HashMap<String, User>();
	
	public void addUser(User user){
		users.put(user.username, user);
	}
	
	public User findByUsername(String username){
		return users.get(username);
	}
}
