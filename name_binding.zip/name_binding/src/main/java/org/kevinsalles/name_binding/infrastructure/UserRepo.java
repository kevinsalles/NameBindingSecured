package org.kevinsalles.name_binding.infrastructure;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;

import org.kevinsalles.name_binding.domain.Role;
import org.kevinsalles.name_binding.domain.User;

public class UserRepo {
	private Map<String,User> users = new HashMap<String, User>();
	
	public void addUser(User user){
		users.put(user.username, user);
	}
	
	public User findByUsername(String username){
		return users.get(username);
	}
	
	public Collection<User> getAllUser(){
		return users.values();
	}
	
	public Collection<User> getClient(){
		return users.entrySet().stream()
				.filter(u -> u.getValue().role.equals(Role.CLIENT))
				.collect(Collectors.toMap(p -> p.getKey(), p -> p.getValue()))
				.values();
	}
}
