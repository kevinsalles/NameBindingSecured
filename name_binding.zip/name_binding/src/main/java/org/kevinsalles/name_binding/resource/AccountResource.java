package org.kevinsalles.name_binding.resource;

import javax.ws.rs.GET;
import javax.ws.rs.HeaderParam;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.kevinsalles.name_binding.domain.User;
import org.kevinsalles.name_binding.filter.Secured;
import org.kevinsalles.name_binding.infrastructure.UserRepo;
import org.kevinsalles.name_binding.infrastructure.UserRepoSingleton;

@Path("/account")
public class AccountResource {

	@GET
	@Secured
	@Produces(MediaType.TEXT_HTML)
	public String account(@HeaderParam("username") String username){
		
		UserRepo repo = UserRepoSingleton.getInstance();
		User user = repo.findByUsername(username);
		return htlmResponse(user);
	}
	
	private String htlmResponse(User user){
		return "<!doctype html>"
				+ "<html lang='fr'>"
				+ "	<head>"
				+ "		<meta charset='utf-8'>"
				+ "		<title>Account user</title>"
				+ "	</head>"
				+ "	<body>"
				+ "     <div style='background-color: rgb(23,52,125);"
				+ "			width: 350px;margin-right: auto;margin-left: auto;"
				+ "			color: white;padding: 10px'>"
				+ "			<h1>"+user.role.toString()+"</h1>"
				+ "			<p>UserName : "+user.username+"</p>"
				+ "			<p>Password : "+user.password+"</p>"
				+ "			<p>isAuthenticated : "+user.isAuthenficate+"</p>"
				+ "		</div>"
				+ "	</body>"
				+ "</html>";
	}
	
}
