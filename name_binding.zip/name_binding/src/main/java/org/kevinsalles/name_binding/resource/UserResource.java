package org.kevinsalles.name_binding.resource;

import java.util.Collection;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.kevinsalles.name_binding.domain.User;
import org.kevinsalles.name_binding.filter.Admin;
import org.kevinsalles.name_binding.filter.GroupAccessClient;
import org.kevinsalles.name_binding.filter.Secured;
import org.kevinsalles.name_binding.infrastructure.UserRepo;
import org.kevinsalles.name_binding.infrastructure.UserRepoSingleton;

@Path("/")
public class UserResource {

	@GET
	@Secured
	@Admin
	@Path("role")
	@Produces(MediaType.TEXT_HTML)
	public String role(){
		
		UserRepo repo = UserRepoSingleton.getInstance();
		Collection<User> users = repo.getAllUser();
		return roleHtlmResponse(users);
	}
	
	@GET
	@Secured
	@GroupAccessClient
	@Path("client")
	@Produces(MediaType.TEXT_HTML)
	public String client(){
		
		UserRepo repo = UserRepoSingleton.getInstance();
		Collection<User> users = repo.getClient();
		return clientHtlmResponse(users);
	}
	
	private String clientHtlmResponse(Collection<User> users){
		String html = "<!doctype html>"
						+ "<html lang='fr'>"
						+ "	<head>"
						+ "		<meta charset='utf-8'>"
						+ "		<title>Account user</title>"
						+ "	</head>"
						+ "	<body>"
						+ "     <div style='background-color: rgb(23,52,125);"
						+ "			width: 350px;margin-right: auto;margin-left: auto;"
						+ "			color: white;padding: 10px'>"
						+ "			<h1>Liste des clients</h1>" ;
		for(User user:users){
			html +=  "	<div style='background-color: rgb(153, 204, 255);color:black;padding: 5px'>"
					+ "	<p>Client : "+user.username+"</p>"
					+ " <p>Role : "+user.role.toString()+"<br>Connecté : "+user.isAuthenficate+"</p>"
					+ " <p></p></div>";
		}
				
		html += "		</div>"
				+ "	</body>"
				+ "</html>";
		
		return html;
	}
	
	private String roleHtlmResponse(Collection<User> users){
		String html = "<!doctype html>"
						+ "<html lang='fr'>"
						+ "	<head>"
						+ "		<meta charset='utf-8'>"
						+ "		<title>Account user</title>"
						+ "	</head>"
						+ "	<body>"
						+ "     <div style='background-color: rgb(23,52,125);"
						+ "			width: 350px;margin-right: auto;margin-left: auto;"
						+ "			color: white;padding: 10px'>"
						+ "			<h1>Liste des rôles</h1>" ;
		for(User user:users){
			html +=  "	<p>"+user.username+" : "+user.role.toString()+"</p>";
		}
				
		html += "		</div>"
				+ "	</body>"
				+ "</html>";
		
		return html;
	}
}
