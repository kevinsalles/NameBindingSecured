package org.kevinsalles.name_binding.infrastructure;

public class UserRepoSingleton {
	
	private UserRepoSingleton(){}
	
	private static class UserRepoSingletonHolder{
		private final static UserRepo INSTANCE = new UserRepo();
	}
	
	public static UserRepo getInstance(){
		return UserRepoSingletonHolder.INSTANCE;
	}
}
