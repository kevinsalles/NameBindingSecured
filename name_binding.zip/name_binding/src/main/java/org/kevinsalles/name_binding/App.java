package org.kevinsalles.name_binding;

import java.util.HashSet;
import java.util.Set;

import javax.ws.rs.core.Application;

import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.servlet.ServletContextHandler;
import org.eclipse.jetty.servlet.ServletHolder;
import org.glassfish.jersey.server.ResourceConfig;
import org.glassfish.jersey.servlet.ServletContainer;
import org.kevinsalles.name_binding.domain.Role;
import org.kevinsalles.name_binding.domain.User;
import org.kevinsalles.name_binding.filter.AdminFilter;
import org.kevinsalles.name_binding.filter.CORSFilter;
import org.kevinsalles.name_binding.filter.SecurityFilter;
import org.kevinsalles.name_binding.infrastructure.UserRepo;
import org.kevinsalles.name_binding.infrastructure.UserRepoSingleton;
import org.kevinsalles.name_binding.resource.AccountResource;
import org.kevinsalles.name_binding.resource.AuthentificationResource;
import org.kevinsalles.name_binding.resource.UserResource;

public class App 
{
	
    public static void main( String[] args )throws Exception {
        ServletContextHandler context = new ServletContextHandler(ServletContextHandler.SESSIONS);
        context.setContextPath("/");
 
        Server jettyServer = new Server(8080);

        ResourceConfig resourceConfig = createResourceConfig();
        ServletContainer servletContainer = new ServletContainer(resourceConfig);
        ServletHolder servletHolder = new ServletHolder(servletContainer);
        context.addServlet(servletHolder, "/*");
        
        jettyServer.setHandler(context);
        
        initializeUser();
 
        try {
            jettyServer.start();
            jettyServer.join();
        } finally {
            jettyServer.destroy();
        }
    }
    
    private static ResourceConfig createResourceConfig() {
    	
        ResourceConfig resourceConfig = ResourceConfig.forApplication(new Application() {
        	Set<Object> resources = new HashSet<Object>();
            @Override
            public Set<Object> getSingletons() {
                resources.add(new AuthentificationResource());
                resources.add(new AccountResource());
                resources.add(new UserResource());
                return resources;
            }
        });
        resourceConfig.register(CORSFilter.class);
        resourceConfig.register(SecurityFilter.class);
        resourceConfig.register(AdminFilter.class);
        return resourceConfig;
    }
    
    private static void initializeUser(){
    	UserRepo userRepo = UserRepoSingleton.getInstance();
    	
    	User user = new User();
    	user.username = "Paul";
    	user.password = "123456";
    	user.isAuthenficate = false;
    	user.role = Role.ADMIN;
    	userRepo.addUser(user);
    	
    	user = new User();
    	user.username = "Nicolas";
    	user.password = "123456";
    	user.isAuthenficate = false;
    	user.role = Role.AGENT;
    	userRepo.addUser(user);
    	
    	user = new User();
    	user.username = "Julie";
    	user.password = "123456";
    	user.isAuthenficate = false;
    	user.role = Role.AGENT;
    	userRepo.addUser(user);
    	
    	user = new User();
    	user.username = "Martin";
    	user.password = "123456";
    	user.isAuthenficate = false;
    	user.role = Role.CLIENT;
    	userRepo.addUser(user);
    	
    	user = new User();
    	user.username = "Marie";
    	user.password = "123456";
    	user.isAuthenficate = false;
    	user.role = Role.CLIENT;
    	userRepo.addUser(user);
    	
    	user = new User();
    	user.username = "Sébastien";
    	user.password = "123456";
    	user.isAuthenficate = false;
    	user.role = Role.CLIENT;
    	userRepo.addUser(user);
    }

}
