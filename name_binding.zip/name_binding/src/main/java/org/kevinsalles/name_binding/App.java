package org.kevinsalles.name_binding;

import java.util.HashSet;
import java.util.Set;

import javax.ws.rs.core.Application;

import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.servlet.ServletContextHandler;
import org.eclipse.jetty.servlet.ServletHolder;
import org.glassfish.jersey.server.ResourceConfig;
import org.glassfish.jersey.servlet.ServletContainer;
import org.kevinsalles.name_binding.domain.User;
import org.kevinsalles.name_binding.filter.CORSFilter;
import org.kevinsalles.name_binding.filter.SecurityFilter;
import org.kevinsalles.name_binding.infrastructure.UserRepo;
import org.kevinsalles.name_binding.infrastructure.UserRepoSingleton;
import org.kevinsalles.name_binding.resource.AccountResource;
import org.kevinsalles.name_binding.resource.AuthentificationResource;

public class App 
{
	
    public static void main( String[] args )throws Exception {
        ServletContextHandler context = new ServletContextHandler(ServletContextHandler.SESSIONS);
        context.setContextPath("/");
 
        Server jettyServer = new Server(8080);

        ResourceConfig resourceConfig = createResourceConfig();
        ServletContainer servletContainer = new ServletContainer(resourceConfig);
        ServletHolder servletHolder = new ServletHolder(servletContainer);
        context.addServlet(servletHolder, "/*");
        
        jettyServer.setHandler(context);
        
        initializeUser();
 
        try {
            jettyServer.start();
            jettyServer.join();
        } finally {
            jettyServer.destroy();
        }
    }
    
    private static ResourceConfig createResourceConfig() {
    	
        ResourceConfig resourceConfig = ResourceConfig.forApplication(new Application() {
        	Set<Object> resources = new HashSet<Object>();
            @Override
            public Set<Object> getSingletons() {
                resources.add(new AuthentificationResource());
                resources.add(new AccountResource());
                return resources;
            }
        });
        resourceConfig.register(CORSFilter.class);
        resourceConfig.register(SecurityFilter.class);
        return resourceConfig;
    }
    
    private static void initializeUser(){
    	UserRepo userRepo = UserRepoSingleton.getInstance();
    	
    	User user = new User();
    	user.username = "Paul";
    	user.password = "123456";
    	user.isAuthenficate = false;
    	
    	userRepo.addUser(user);
    }

}
