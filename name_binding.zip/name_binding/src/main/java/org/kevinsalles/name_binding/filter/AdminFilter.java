package org.kevinsalles.name_binding.filter;

import java.io.IOException;

import javax.annotation.Priority;
import javax.ws.rs.NotAuthorizedException;
import javax.ws.rs.Priorities;
import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.container.ContainerRequestFilter;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.ext.Provider;

import org.kevinsalles.name_binding.domain.Role;
import org.kevinsalles.name_binding.domain.User;
import org.kevinsalles.name_binding.infrastructure.UserRepo;
import org.kevinsalles.name_binding.infrastructure.UserRepoSingleton;

@Admin
@Provider
@Priority(Priorities.USER)
public class AdminFilter implements ContainerRequestFilter {

	public void filter(ContainerRequestContext requestContext) throws IOException {
		UriInfo uriInfo = requestContext.getUriInfo();
        String name = requestContext.getHeaderString("username");

        if (uriInfo == null) {
            throw new NotAuthorizedException("Authorization header must be provided");
        }

	    if(!validateAdmin(name)){
	    	requestContext.abortWith(
	                Response.status(Response.Status.UNAUTHORIZED).build());
        }
	}
	
	private boolean validateAdmin(String username) {
    	UserRepo repo = UserRepoSingleton.getInstance();
		
		User user = repo.findByUsername(username);
		if(user.role.equals(Role.ADMIN)){
			return true;
		}
		
		return false;
    }

}
