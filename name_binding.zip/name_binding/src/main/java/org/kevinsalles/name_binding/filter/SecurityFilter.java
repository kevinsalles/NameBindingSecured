package org.kevinsalles.name_binding.filter;

import java.io.IOException;

import javax.annotation.Priority;
import javax.ws.rs.NotAuthorizedException;
import javax.ws.rs.Priorities;
import javax.ws.rs.container.ContainerRequestContext;
import javax.ws.rs.container.ContainerRequestFilter;
import javax.ws.rs.core.Response;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.ext.Provider;

import org.kevinsalles.name_binding.domain.User;
import org.kevinsalles.name_binding.infrastructure.UserRepo;
import org.kevinsalles.name_binding.infrastructure.UserRepoSingleton;

@Secured
@Provider
@Priority(Priorities.AUTHENTICATION)
public class SecurityFilter implements ContainerRequestFilter {

    public void filter(ContainerRequestContext requestContext) throws IOException {

        UriInfo uriInfo = requestContext.getUriInfo();

        if (uriInfo == null) {
            throw new NotAuthorizedException("Authorization header must be provided");
        }

	    if(!validateUser(extractUsernameToUrl(uriInfo))){
	    	requestContext.abortWith(
	                Response.status(Response.Status.UNAUTHORIZED).build());
        }
    }

    private boolean validateUser(String username) {
    	UserRepo repo = UserRepoSingleton.getInstance();
		
		User user = repo.findByUsername(username);
		if(user == null){
			return false;
		}
		
		return user.isAuthenficate;
    }
    
    private String extractUsernameToUrl(UriInfo uriInfo){
    	String url = uriInfo.getPath();
        String[] urlInfo = url.split("/");
        return urlInfo[urlInfo.length-1];
    }
}
