package org.kevinsalles.name_binding.domain;

public class User {
	public String username;
	public String password;
	public boolean isAuthenficate;
	public Role role;
}
